# /// script
# requires-python = ">=3.11"
# dependencies = [
#     "pyside6>=6.4.0",
#     "fastapi>=0.95.0",
#     "requests>=2.28.2",
#     "uvicorn>=0.21.0",
# ]
# ///

import sys
import json
import logging
from pathlib import Path
from typing import Dict, Any
from datetime import datetime

from PySide6.QtWidgets import (
    QApplication,
    QMainWindow,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QComboBox,
    QTextEdit,
    QLabel,
    QPushButton,
    QSplitter,
)
from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtGui import QColor, QTextCharFormat, QFont, QTextCursor

import uvicorn
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse


# 設定日誌
def setup_logging():
    # 創建 logs 目錄（如果不存在）
    log_dir = Path(__file__).parent / "logs"
    log_dir.mkdir(exist_ok=True)

    # 設定日誌檔案名稱（使用當天日期）
    current_date = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file = log_dir / f"webapi_{current_date}.log"

    # 設定根日誌記錄器
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.INFO)

    # 設定檔案處理器
    file_handler = logging.FileHandler(log_file, encoding="utf-8")
    file_formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s", datefmt="%Y-%m-%d %H:%M:%S")
    file_handler.setFormatter(file_formatter)
    root_logger.addHandler(file_handler)

    # 設定控制台處理器
    console_handler = logging.StreamHandler()
    console_formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(message)s", datefmt="%H:%M:%S")
    console_handler.setFormatter(console_formatter)
    root_logger.addHandler(console_handler)

    return root_logger


# 初始化日誌
logger = setup_logging()


# 使用 PyInstaller 打包時，_MEIPASS 會被設置為臨時目錄的路徑
def get_path() -> Path:
    try:
        base_path = Path(sys._MEIPASS)
    except AttributeError:
        base_path = Path(__file__).parent
    return base_path


# 讀取配置文件
def load_config() -> Dict[str, Any]:
    config_path = get_path() / "config.json"
    print(config_path)
    try:
        with open(config_path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        logger.error(f"無法讀取配置文件: {e}")
        return {}


# 保存配置文件
def save_config(config: Dict[str, Any]) -> bool:
    config_path = get_path() / "config.json"
    try:
        with open(config_path, "w", encoding="utf-8") as f:
            json.dump(config, f, ensure_ascii=False, indent=4)
        return True
    except Exception as e:
        logger.error(f"無法保存配置文件: {e}")
        return False


# FastAPI 服務器線程
class APIServerThread(QThread):
    log_signal = Signal(str, str)  # 訊息, 類型 (info/error)
    request_signal = Signal(str)  # 請求內容
    response_signal = Signal(str)  # 響應內容

    def __init__(self, config: Dict[str, Any], main_window=None):
        super().__init__()
        self.config = config
        self.main_window = main_window
        self.app = FastAPI()
        self.setup_routes()

    def setup_routes(self):
        # /api/v1/health
        @self.app.get(self.config["api"]["endpoints"]["health"]["path"])
        async def health():
            self.log_signal.emit("收到 Health 請求", "info")
            request_info = "GET /api/v1/health"
            self.request_signal.emit(request_info)

            # 檢查當前選擇的路徑是否為 health
            if self.main_window:
                current_path = self.main_window.get_current_path()
                if current_path == "/api/v1/health":
                    # 使用文字框的內容作為響應
                    try:
                        response_content = self.main_window.get_response_content()
                        if response_content and response_content != "GET 請求，無需內容":
                            response = json.loads(response_content)
                            self.response_signal.emit(json.dumps(response, indent=4, ensure_ascii=False))
                            return response
                    except json.JSONDecodeError:
                        self.log_signal.emit("無法解析回應內容的JSON格式", "error")
                    except Exception as e:
                        self.log_signal.emit(f"處理回應內容時出錯: {e}", "error")

            # 如果無法使用文字框內容，使用預設響應
            default_response = {"status": "ok", "message": "Service is healthy"}
            self.response_signal.emit(json.dumps(default_response, indent=4, ensure_ascii=False))
            return default_response

        # /api/v1/jsonrpc
        @self.app.post(self.config["api"]["endpoints"]["jsonrpc"]["path"])
        async def jsonrpc(request: Request):
            try:
                data = await request.json()
                request_info = f"POST /api/v1/jsonrpc\n{json.dumps(data, indent=4, ensure_ascii=False)}"
                self.request_signal.emit(request_info)
                self.log_signal.emit(f"收到 JSONRPC 請求: {data}", "info")

                # 檢查是否符合 JSONRPC 2.0 規格
                if not isinstance(data, dict) or data.get("jsonrpc") != "2.0":
                    self.log_signal.emit("無效的 JSONRPC 請求", "error")
                    error_response = self.config["api"]["endpoints"]["jsonrpc"]["error_response"]
                    self.response_signal.emit(json.dumps(error_response, indent=4, ensure_ascii=False))
                    return JSONResponse(content=error_response)

                # 檢查當前選擇的路徑是否為 jsonrpc
                if self.main_window:
                    current_path = self.main_window.get_current_path()
                    if current_path == "/api/v1/jsonrpc":
                        # 使用文字框的內容作為響應
                        try:
                            response_content = self.main_window.get_response_content()
                            if response_content:
                                response = json.loads(response_content)
                                if "id" in data:
                                    response["id"] = data["id"]
                                self.response_signal.emit(json.dumps(response, indent=4, ensure_ascii=False))
                                return response
                        except json.JSONDecodeError:
                            self.log_signal.emit("無法解析回應內容的JSON格式", "error")
                        except Exception as e:
                            self.log_signal.emit(f"處理回應內容時出錯: {e}", "error")

                # 如果無法使用文字框內容，使用預設響應
                response = {"jsonrpc": "2.0", "result": "Success", "id": data.get("id", 1)}
                self.response_signal.emit(json.dumps(response, indent=4, ensure_ascii=False))
                return response
            except Exception as e:
                self.log_signal.emit(f"處理 JSONRPC 請求時出錯: {e}", "error")
                error_response = self.config["api"]["endpoints"]["jsonrpc"]["error_response"]
                self.response_signal.emit(json.dumps(error_response, indent=4, ensure_ascii=False))
                return JSONResponse(content=error_response)

    def run(self):
        host = self.config["api"]["host"]
        port = self.config["api"]["port"]
        self.log_signal.emit(f"啟動 API 服務器於 {host}:{port}", "info")
        uvicorn.run(self.app, host=host, port=port, log_level="error")


# 自定義日誌顯示區域
class LogTextEdit(QTextEdit):
    def __init__(self):
        super().__init__()
        self.setReadOnly(True)
        self.setStyleSheet("background-color: black;")

        # 設置格式
        self.info_format = QTextCharFormat()
        self.info_format.setForeground(QColor("lime"))
        self.info_format.setFont(QFont("Consolas", 10))

        self.error_format = QTextCharFormat()
        self.error_format.setForeground(QColor("red"))
        self.error_format.setFont(QFont("Consolas", 10, QFont.Bold))

    def append_log(self, message: str, log_type: str = "info"):
        # 取得當前時間
        timestamp = datetime.now()
        ui_timestamp = timestamp.strftime("%H:%M:%S")
        # 在界面上顯示日誌
        cursor = self.textCursor()
        cursor.movePosition(QTextCursor.End)

        if log_type == "error":
            cursor.insertText(f"[{ui_timestamp}] {message}\n", self.error_format)
            logger.error(message)  # 使用全局 logger 記錄錯誤
        else:
            cursor.insertText(f"[{ui_timestamp}] {message}\n", self.info_format)
            logger.info(message)  # 使用全局 logger 記錄信息

        # 自動滾動到底部
        self.setTextCursor(cursor)
        self.ensureCursorVisible()


# 主窗口
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.config = load_config()
        self.init_ui()
        self.start_api_server()

    def init_ui(self):
        self.setWindowTitle("WebAPI 工具")
        self.setGeometry(100, 100, 800, 600)

        # 主佈局
        main_widget = QWidget()
        main_layout = QVBoxLayout(main_widget)

        # 創建分割器
        splitter = QSplitter(Qt.Vertical)

        # 上部分 - 操控區 (1/4 比例)
        control_widget = QWidget()
        control_layout = QHBoxLayout(control_widget)  # 改為水平佈局

        # 左側佈局 (下拉選單在上，保存設定在下)
        left_layout = QVBoxLayout()

        # 路徑選擇區域 (左上)
        path_layout = QVBoxLayout()
        path_label = QLabel("API 路徑:")
        self.path_combo = QComboBox()
        self.path_combo.currentTextChanged.connect(self.update_message_box)

        # 添加編輯路徑按鈕
        self.add_path_button = QPushButton("添加路徑")
        self.add_path_button.clicked.connect(self.add_new_path)
        self.remove_path_button = QPushButton("移除路徑")
        self.remove_path_button.clicked.connect(self.remove_current_path)

        path_layout.addWidget(path_label)
        path_layout.addWidget(self.path_combo)
        path_buttons_layout = QHBoxLayout()
        path_buttons_layout.addWidget(self.add_path_button)
        path_buttons_layout.addWidget(self.remove_path_button)
        path_layout.addLayout(path_buttons_layout)
        left_layout.addLayout(path_layout)

        # 添加彈性空間
        left_layout.addStretch(1)

        # 保存設定按鈕 (左下)
        self.save_button = QPushButton("保存設定")
        self.save_button.clicked.connect(self.save_settings)
        left_layout.addWidget(self.save_button)

        # 右側佈局 (文字框)
        right_layout = QVBoxLayout()
        message_label = QLabel("回應內容:")
        self.message_edit = QTextEdit()

        # 使用 get 方法安全地獲取設定值，如果不存在則使用預設值
        default_message = self.config.get("ui", {}).get(
            "default_message",
            json.dumps({"status": "ok", "message": "Service is healthy"}, indent=4, ensure_ascii=False),
        )
        self.message_edit.setPlainText(default_message)

        right_layout.addWidget(message_label)
        right_layout.addWidget(self.message_edit)

        # 將左側和右側布局添加到水平布局中
        left_container = QWidget()
        left_container.setLayout(left_layout)
        right_container = QWidget()
        right_container.setLayout(right_layout)

        # 設置左側寬度為右側的 1/3
        control_layout.addWidget(left_container, 3)
        control_layout.addWidget(right_container, 7)

        # 下部分 - 顯示區
        display_widget = QWidget()
        display_layout = QVBoxLayout(display_widget)

        # 請求顯示區域
        request_label = QLabel("請求:")
        self.request_edit = QTextEdit()
        self.request_edit.setReadOnly(True)

        # 響應顯示區域
        response_label = QLabel("響應:")
        self.response_edit = QTextEdit()
        self.response_edit.setReadOnly(True)

        # 日誌顯示區域
        log_label = QLabel("日誌:")
        self.log_edit = LogTextEdit()

        # 添加到顯示區佈局
        display_layout.addWidget(request_label)
        display_layout.addWidget(self.request_edit, 3)  # 30% 的空間
        display_layout.addWidget(response_label)
        display_layout.addWidget(self.response_edit, 4)  # 40% 的空間
        display_layout.addWidget(log_label)
        display_layout.addWidget(self.log_edit, 3)  # 30% 的空間

        # 添加到分割器
        splitter.addWidget(control_widget)
        splitter.addWidget(display_widget)

        # 設置分割器比例 (1:4)
        splitter.setSizes([1, 4])

        # 添加到主佈局
        main_layout.addWidget(splitter)

        # 設置中央窗口
        self.setCentralWidget(main_widget)

        # 初始日誌
        self.log_edit.append_log("WebAPI 工具已啟動")

        # 在所有 UI 元件初始化完成後，才載入路徑
        self.load_paths_from_config()

    def start_api_server(self):
        self.server_thread = APIServerThread(self.config, self)
        self.server_thread.log_signal.connect(self.handle_log)
        self.server_thread.request_signal.connect(self.handle_request)
        self.server_thread.response_signal.connect(self.handle_response)
        self.server_thread.start()

    def handle_log(self, message: str, log_type: str):
        self.log_edit.append_log(message, log_type)

    def handle_request(self, request: str):
        self.request_edit.setPlainText(request)

    def handle_response(self, response: str):
        self.response_edit.setPlainText(response)

    def load_paths_from_config(self):
        # 從設定檔中讀取所有API路徑及其響應
        self.path_combo.clear()
        self.path_response_map = {}  # 用於存儲路徑-響應的映射關係

        # 從endpoints中獲取所有路徑及其響應
        for endpoint, data in self.config["api"]["endpoints"].items():
            if "path" in data and "responses" in data and isinstance(data["responses"], list):
                path = data["path"]
                for response in data["responses"]:
                    if "name" in response and "content" in response:
                        combo_text = f"{path} - {response['name']}"
                        self.path_combo.addItem(combo_text)
                        # 保存路徑-響應的映射關係
                        self.path_response_map[combo_text] = {
                            "path": path,
                            "response_name": response["name"],
                            "response_content": response["content"],
                        }

        # 如果UI中有額外的路徑，也添加進來
        if "paths" in self.config["ui"]:
            for path in self.config["ui"]["paths"]:
                # 檢查該路徑是否已經在下拉選單中
                exists = False
                for i in range(self.path_combo.count()):
                    if path in self.path_combo.itemText(i):
                        exists = True
                        break

                if not exists:
                    self.path_combo.addItem(path)
                    self.path_response_map[path] = {
                        "path": path,
                        "response_name": "默認",
                        "response_content": {},
                    }

        # 如果有項目，預設選擇第一個
        if self.path_combo.count() > 0:
            self.path_combo.setCurrentIndex(0)
            # 觸發更新訊息框
            self.update_message_box(self.path_combo.currentText())

    def add_new_path(self):
        # 獲取當前所有路徑
        current_paths = set()
        for i in range(self.path_combo.count()):
            combo_text = self.path_combo.itemText(i)
            if combo_text in self.path_response_map:
                current_paths.add(self.path_response_map[combo_text]["path"])
            elif " - " in combo_text:
                current_paths.add(combo_text.split(" - ", 1)[0])
            else:
                current_paths.add(combo_text)

        # 添加新路徑（這裡簡單實現，實際應用可能需要彈出對話框讓用戶輸入）
        new_path = f"/api/v1/custom_{len(current_paths)}"
        new_response_name = "默認響應"

        # 確保路徑不重複
        if new_path not in current_paths:
            combo_text = f"{new_path} - {new_response_name}"
            self.path_combo.addItem(combo_text)
            self.log_edit.append_log(f"添加了新路徑: {new_path} 和響應: {new_response_name}")

            # 更新路徑-響應映射
            self.path_response_map[combo_text] = {
                "path": new_path,
                "response_name": new_response_name,
                "response_content": {},
            }

            # 更新設定檔中的路徑列表
            if "paths" in self.config["ui"]:
                if new_path not in self.config["ui"]["paths"]:
                    self.config["ui"]["paths"].append(new_path)
            else:
                self.config["ui"]["paths"] = list(current_paths) + [new_path]
        else:
            # 如果路徑已存在，添加新的響應名稱
            response_count = 0
            for i in range(self.path_combo.count()):
                combo_text = self.path_combo.itemText(i)
                if combo_text in self.path_response_map and self.path_response_map[combo_text]["path"] == new_path:
                    response_count += 1

            new_response_name = f"響應 {response_count + 1}"
            combo_text = f"{new_path} - {new_response_name}"
            self.path_combo.addItem(combo_text)
            self.log_edit.append_log(f"為路徑 {new_path} 添加了新響應: {new_response_name}")

            # 更新路徑-響應映射
            self.path_response_map[combo_text] = {
                "path": new_path,
                "response_name": new_response_name,
                "response_content": {},
            }

    def remove_current_path(self):
        current_combo_text = self.path_combo.currentText()
        current_index = self.path_combo.currentIndex()

        if current_index >= 0:
            self.path_combo.removeItem(current_index)

            # 獲取路徑和響應名稱
            if current_combo_text in self.path_response_map:
                path_info = self.path_response_map[current_combo_text]
                path = path_info["path"]
                response_name = path_info["response_name"]

                # 從映射中移除
                del self.path_response_map[current_combo_text]

                # 檢查是否還有其他使用相同路徑的項目
                has_same_path = False
                for combo_text, info in self.path_response_map.items():
                    if info["path"] == path:
                        has_same_path = True
                        break

                # 如果沒有其他使用相同路徑的項目，從UI路徑列表中移除
                if not has_same_path and "paths" in self.config["ui"]:
                    if path in self.config["ui"]["paths"]:
                        self.config["ui"]["paths"].remove(path)

                self.log_edit.append_log(f"移除了路徑 {path} 的 {response_name} 響應")
            else:
                # 處理可能的舊格式路徑
                if " - " in current_combo_text:
                    parts = current_combo_text.split(" - ", 1)
                    path = parts[0]
                    response_name = parts[1] if len(parts) > 1 else "默認"
                else:
                    path = current_combo_text
                    response_name = "默認"

                # 從UI路徑列表中移除
                if "paths" in self.config["ui"]:
                    if path in self.config["ui"]["paths"]:
                        self.config["ui"]["paths"].remove(path)

                self.log_edit.append_log(f"移除了路徑: {path}")
        else:
            self.log_edit.append_log("沒有選擇路徑，無法移除", "error")

    def update_message_box(self, combo_text: str):
        # 根據選擇的路徑和響應名稱更新訊息框，顯示對應的響應內容
        if combo_text in self.path_response_map:
            response_info = self.path_response_map[combo_text]
            path = response_info["path"]
            response_name = response_info["response_name"]
            response_content = response_info["response_content"]

            # 顯示對應路徑和響應名稱的響應內容
            if response_content:
                self.message_edit.setPlainText(json.dumps(response_content, indent=4, ensure_ascii=False))
                self.log_edit.append_log(f"已載入 [{path} - {response_name}] 響應內容")
                return
        else:
            # 如果沒有在映射中找到，可能是舊格式的路徑
            path = combo_text

            # 遍歷所有endpoints尋找匹配的路徑
            for endpoint, data in self.config["api"]["endpoints"].items():
                if data.get("path") == path:
                    if "responses" in data and isinstance(data["responses"], list) and data["responses"]:
                        # 使用第一個響應
                        response = data["responses"][0]
                        self.message_edit.setPlainText(json.dumps(response["content"], indent=4, ensure_ascii=False))
                        self.log_edit.append_log(f"已載入 [{path} - {response['name']}] 響應內容")
                        return

        # 如果沒有找到對應的響應內容，使用默認處理
        if "health" in combo_text:
            self.message_edit.setPlainText("GET 請求，無需內容")
        elif "jsonrpc" in combo_text:
            default_jsonrpc = {
                "jsonrpc": "2.0",
                "method": "example.method",
                "params": {"param1": "value1"},
                "id": 1,
            }
            self.message_edit.setPlainText(json.dumps(default_jsonrpc, indent=4))

    def send_request(self):
        # 根據需求，API只會回應請求，本身不發送請求
        self.log_edit.append_log("API服務器只會回應請求，不會主動發送請求", "info")
        self.response_edit.setPlainText("API服務器處於監聽模式，等待外部請求")

    def save_settings(self):
        # 保存當前設定到配置文件
        try:
            # 獲取當前選擇的路徑和響應名稱
            current_combo_text = self.path_combo.currentText()

            # 解析路徑和響應名稱
            if current_combo_text in self.path_response_map:
                path_info = self.path_response_map[current_combo_text]
                current_path = path_info["path"]
                cur_response_name = path_info["response_name"]
            else:
                # 如果沒有在映射中找到，可能是舊格式的路徑或新添加的路徑
                if " - " in current_combo_text:
                    parts = current_combo_text.split(" - ", 1)
                    current_path = parts[0]
                    cur_response_name = parts[1] if len(parts) > 1 else "默認"
                else:
                    current_path = current_combo_text
                    cur_response_name = "默認"

            # 嘗試更新當前路徑的響應內容
            try:
                # 解析文字框中的JSON內容
                message_content = self.message_edit.toPlainText()
                if message_content and message_content != "GET 請求，無需內容":
                    message_json = json.loads(message_content)

                    # 查找並更新對應路徑的響應內容
                    updated = False
                    for endpoint, data in self.config["api"]["endpoints"].items():
                        if data.get("path") == current_path:
                            # 檢查是否已有responses字段
                            if "responses" not in data or not isinstance(data["responses"], list):
                                data["responses"] = []

                            # 查找並更新對應名稱的響應
                            response_updated = False
                            for i, response in enumerate(data["responses"]):
                                if response.get("name") == cur_response_name:
                                    data["responses"][i]["content"] = message_json
                                    response_updated = True
                                    break

                            # 如果沒有找到對應名稱的響應，添加新的響應
                            if not response_updated:
                                data["responses"].append({"name": cur_response_name, "content": message_json})

                            updated = True
                            self.log_edit.append_log(f"已更新 {current_path} 的 {cur_response_name} 響應內容")
                            break

                    # 如果沒有找到對應的endpoint，創建新的endpoint
                    if not updated:
                        # 創建新的endpoint
                        new_endpoint_name = f"custom_{len(self.config['api']['endpoints'])}"
                        self.config["api"]["endpoints"][new_endpoint_name] = {
                            "path": current_path,
                            "responses": [{"name": cur_response_name, "content": message_json}],
                        }
                        self.log_edit.append_log(
                            f"已創建新的endpoint: {new_endpoint_name} 用於路徑 {current_path} 的 {cur_response_name} 響應"
                        )
            except json.JSONDecodeError:
                self.log_edit.append_log("無法解析JSON內容，響應內容未更新", "error")
            except Exception as e:
                self.log_edit.append_log(f"更新響應內容時出錯: {e}", "error")

            # 更新默認訊息
            self.config["ui"]["default_message"] = self.message_edit.toPlainText()

            # 更新UI中的路徑列表
            ui_paths = []
            for i in range(self.path_combo.count()):
                combo_text = self.path_combo.itemText(i)
                if combo_text in self.path_response_map:
                    path = self.path_response_map[combo_text]["path"]
                    if path not in ui_paths:
                        ui_paths.append(path)
                else:
                    # 處理可能的舊格式路徑
                    if " - " in combo_text:
                        path = combo_text.split(" - ", 1)[0]
                    else:
                        path = combo_text
                    if path not in ui_paths:
                        ui_paths.append(path)

            self.config["ui"]["paths"] = ui_paths

            # 保存配置
            if save_config(self.config):
                self.log_edit.append_log("設定已保存")
                # 重新加載路徑列表，確保UI與設定檔同步
                self.load_paths_from_config()
            else:
                self.log_edit.append_log("保存設定失敗", "error")
        except Exception as e:
            self.log_edit.append_log(f"保存設定時出錯: {e}", "error")

    def get_current_path(self):
        current_combo_text = self.path_combo.currentText()
        if current_combo_text in self.path_response_map:
            return self.path_response_map[current_combo_text]["path"]
        return current_combo_text

    def get_response_content(self):
        return self.message_edit.toPlainText()

    def closeEvent(self, event):
        # 關閉時停止服務器線程
        if hasattr(self, "server_thread") and self.server_thread.isRunning():
            self.server_thread.terminate()
            self.server_thread.wait()
        event.accept()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())
